import java.util.Scanner;

public class matrixMul {
	
	public static int[][] imultiply(int[][] a, int[][] b){
		int rowsA = a.length;
		int rowsB = a[0].length;
		int colsB = b[0].length;
		
		int[][]c = new int[rowsA][colsB];
		
		for(int i =0; i < rowsA; i++){
			for (int j=0; j <rowsB; j++){
				for (int k=0;k<colsB; k++){
					c[i][j] = a[i][k] + b[k][j];
				}
			}
		}
		return c;
	}
	
	public static void main(String[] args){
		
		int rowsA, rowsB, colsA, colsB;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter rows in matrix 1");
		rowsA = sc.nextInt();
		
		System.out.println("Enter rows in matrix 2");
		rowsB = sc.nextInt();
		
		System.out.println("Enter columns in matrix 2");
		colsB = sc.nextInt();
		
		colsA = rowsB;
		
		int[][] a = new int[rowsA][colsA];
		int[][] b = new int[rowsB][colsB];
		
		System.out.println("Enter 1st Matrix");
		for(int i = 0; i <a.length; i++){
			for(int j = 0; j < a[0].length; j++){
				a[i][j] = sc.nextInt();
			}
		}
		
		System.out.println("Enter 2nd Matrix");
		for(int i = 0; i <b.length; i++){
			for(int j = 0; j < b[0].length; j++){
				b[i][j] = sc.nextInt();
			}
		}
		
		//int[][] c = iterativeMultiplication(a,b);
		//System.out.println("Result: ");
		//for(int i = 0; i <c.length; i++){
			//for(int j = 0; j < c[0].length; j++){
				//System.out.print(c[i][j] + " ");
			//}
			//System.out.println(" ");
		//}
	}

}
