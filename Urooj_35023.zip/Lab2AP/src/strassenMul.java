import java.util.Scanner;
//strassen algorithm implemented in lab1 for 2x2
public class strassenMul {

	public static int[][] multiply(int[][] a, int[][]b){
		
		int n = a.length;
		int[][] R = new int [n][n];
		
		if(n == 1)
			R[0][0] = a[0][0] * b[0][0];
		
		else
		{
		
		int  M1 = ((a[0][0] + a[1][1])*(b[0][0]+ b[1][1]));
		int  M2 = ((a[1][0] + a[1][1])*b[0][0]);
		int  M3 = (a[0][0]*(b[0][1]-b[1][1]));
		int  M4 = (a[1][1]*(b[1][0]-b[0][0]));
		int  M5 = ((a[0][0]+a[1][1])*b[1][1]);
		int  M6 = ((a[1][0]-a[0][0])*(b[0][0]+ b[1][1]));
		int  M7 = ((a[0][1]- a[1][1])*(b[1][0]+b[1][1]));
		
		 R[0][0] = M1 + M4 - M5 + M7;
		 R[0][1] = M3 + M5;
		 R[1][0] = M2 + M4;
		 R[1][1] = M1 - M2 + M3 + M6;
		
		}
		
		return R;
		
	}
	
	public static void main (String[] args){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Strassen Multiplication for 2x2");
		System.out.println(" ");
		
		strassenMul s = new strassenMul();
		
		System.out.println("Enter order n: ");
		int order = sc.nextInt();
		
		//Taking two 2x2 matrices for now
		
		System.out.println("Enter matrix 1 of order 2");
		int[][] a = new int [order][order];
		for (int i = 0; i < order; i++){
			for (int j = 0; j < order; j++){
				a[i][j] = sc.nextInt();
			}
		}
		
		System.out.println("Enter matrix 2 of order 2");
		int[][] b = new int [order][order];
		for (int i = 0; i < order; i++){
			for (int j = 0; j < order; j++){
				b[i][j] = sc.nextInt();
			}
		}
		
		int [][] c = s.multiply(a, b);
		
		System.out.println("\nProduct of matrices a and b: ");
		for (int i = 0; i < order; i++){
			for (int j = 0; j < order; j++){
				System.out.print(c[i][j] + " ");
			}
			System.out.println();
		}
		
		//test cases
		
	}
}
