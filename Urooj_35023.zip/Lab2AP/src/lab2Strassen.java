import java.util.Scanner;
import java.lang.*;
//lab 2 main
public class lab2Strassen {
	
	public static int findN(int order){
		int a = (int) (Math.log(order)+ 1);
		System.out.println(a);
		int n = (int) Math.pow(a, 2);
		return n;
	}
	
	
	public static void main(String[] arg){
		Scanner sc = new Scanner(System.in);
		System.out.println("Strassen Multiplication for 2x2");
		System.out.println(" ");
		
		System.out.println("Enter rows in Matrix A: ");
		int rowsInA = sc.nextInt();
		System.out.println("Enter columns in Matrix A: ");
		int colsInA = sc.nextInt();
		System.out.println("No. of columns in Matrix A = No. of rows in Matrix B.\n");
		System.out.println("Enter columns in Matrix B: ");
		int colsInB = sc.nextInt();
		
		int orderi, orderf = 0;
		
		//checking the largest of which order matrix is to be made
		if(rowsInA >= colsInA){
			orderi = rowsInA;
		}
		else 
			orderi = colsInA;
		
		if(orderi >= colsInB){
			orderf = orderi;
		}
		else 
			orderf = colsInB;
		
		System.out.println("Order: " + orderf);
				
		int n = findN(orderf);
		
		int[][] a = new int[n][n];
		int[][] b = new int[n][n];
		
		
		for(int i = 0; i < n ; i++){
			for(int j = 0; j < n; j++){
				a[i][j] = 0;
			}
		}
		
		for(int i = 0; i < n ; i++){
			for(int j = 0; j < n; j++){
				b[i][j] = 0;
			}
		}
		
		System.out.println("Enter 1st Matrix: \n");
		for(int i = 0; i < rowsInA ; i++){
			for(int j = 0; j < colsInA; j++){
				a[i][j] = sc.nextInt();
			}
		}
		
		System.out.println("Enter 2nd Matrix: \n");
		for(int i = 0; i < colsInA ; i++){
			for(int j = 0; j < colsInB; j++){
				b[i][j] = sc.nextInt();
			}
		}
		
		System.out.println("1st Matrix: \n");
		for(int i = 0; i < n ; i++){
			for(int j = 0; j < n; j++){
				System.out.println(a[i][j]+ " ");
			}
			System.out.println();
		}
		
		System.out.println("2nd Matrix: \n");
		for(int i = 0; i < n ; i++){
			for(int j = 0; j < n; j++){
				System.out.println(b[i][j]+ " ");
			}
			System.out.println();
		}
		
		Strassen s = new Strassen();
		matrixMul m = new matrixMul();
		
		int[][]C = s.multiply(a, b);
		//int[][]D = m.imultiply(a, b);
		
		System.out.println("\nProduct of matrices A and  B : ");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
                System.out.print(C[i][j] +" ");
            System.out.println();
        }
        

	}
	
}
